# Sistema de Tickets - Llantera Móvil Cofradía

## Descripción del Proyecto
Sistema web profesional para generar e imprimir tickets de servicio para Llantera Móvil Cofradía. Incluye formulario de captura, generación de tickets optimizados para impresión, y **sistema de historial local** con almacenamiento en localStorage.

## 🚀 URLs de Acceso
- **Aplicación Web**: https://3000-idxjni5ysd9k51lgrqi8y-6532622b.e2b.dev/
- **API Endpoint**: https://3000-idxjni5ysd9k51lgrqi8y-6532622b.e2b.dev/api/generar-ticket

## ✅ Funcionalidades Completadas

### Interfaz Mejorada
- ✅ **Navegación profesional**: Barra superior con logo en blanco y negro
- ✅ **Logos optimizados**: Filtros CSS para convertir logos a blanco y negro
- ✅ **Diseño responsive**: Funciona en computadora, tablet y móvil
- ✅ **Navegación intuitiva**: Botones "Nuevo Ticket" e "Historial"

### Formulario de Captura
- ✅ **Datos de la empresa cliente**: Nombre de empresa
- ✅ **Información del chofer**: Nombre del conductor
- ✅ **Datos de contacto**: Teléfono del cliente
- ✅ **Ubicación**: Dirección de servicio
- ✅ **Productos/Servicios**: Sistema dinámico para agregar múltiples servicios
- ✅ **Gestión de precios**: Cantidad, precio unitario y cálculo automático de subtotales
- ✅ **Total automático**: Cálculo en tiempo real del monto total

### Sistema de Tickets
- ✅ **Diseño profesional**: Logo de Llantera Móvil Cofradía en blanco y negro
- ✅ **Información de contacto**: Datos completos de la empresa
- ✅ **ID único**: Generación automática de número de ticket
- ✅ **Fecha y hora**: Timestamp automático
- ✅ **Desglose detallado**: Lista completa de productos/servicios
- ✅ **Formato optimizado**: Diseño específico para impresión (80mm)

### 🆕 Sistema de Historial Local
- ✅ **Almacenamiento local**: Usa localStorage del navegador
- ✅ **Historial completo**: Guarda todos los tickets generados
- ✅ **Información detallada**: Fecha, cliente, servicios, totales
- ✅ **Función "Reimprimir"**: Vuelve a imprimir cualquier ticket anterior
- ✅ **Eliminar tickets**: Opción para limpiar tickets individuales
- ✅ **Exportar a CSV**: Descarga el historial completo en formato Excel
- ✅ **Limpiar historial**: Opción para borrar todo el historial
- ✅ **Persistencia**: Los datos se mantienen aunque cierres el navegador

### Funcionalidad de Impresión y Compartir
- ✅ **Impresión directa**: Botón para imprimir desde el navegador
- ✅ **Formato hoja completa**: Tickets ocupan toda la página con letras grandes
- ✅ **Ocultar elementos no necesarios**: Solo imprime el ticket
- ✅ **Reimpresión**: Puedes reimprimir cualquier ticket del historial
- ✅ **🆕 Función Compartir**: Comparte tickets por múltiples canales
- ✅ **WhatsApp**: Envía el ticket directamente por WhatsApp
- ✅ **Email**: Comparte por correo electrónico
- ✅ **Facebook**: Publica en redes sociales
- ✅ **Copiar texto**: Copia el ticket completo al portapapeles

## 🎯 Rutas y Parámetros de la API

### GET /
**Descripción**: Página principal con formulario de captura y navegación
**Response**: HTML completo de la aplicación con historial

### POST /api/generar-ticket
**Descripción**: Procesa datos del formulario y genera ticket
**Content-Type**: application/json

**Parámetros de entrada**:
```json
{
  "empresa": "string",
  "chofer": "string", 
  "telefono": "string",
  "direccion": "string",
  "productos": [
    {
      "descripcion": "string",
      "cantidad": number,
      "precio": number,
      "subtotal": number
    }
  ],
  "total": number,
  "fecha": "string"
}
```

**Response**:
```json
{
  "success": true,
  "ticketId": "string (timestamp)",
  "data": { /* datos enviados */ }
}
```

## 📋 Datos de la Empresa
- **Nombre**: LLANTERA MÓVIL COFRADÍA
- **Servicio**: Servicio a domicilio 24 horas
- **Ubicación**: Mazamitla, Jalisco
- **Teléfono**: 333-485-4080

## 🛠️ Arquitectura Técnica
- **Backend**: Hono Framework (TypeScript)
- **Frontend**: HTML5 + TailwindCSS + JavaScript Vanilla
- **Almacenamiento**: localStorage (navegador)
- **Deployment**: Cloudflare Pages
- **Gestión de procesos**: PM2
- **Control de versiones**: Git

## 👤 Guía de Uso

### Para Generar un Ticket:
1. **Abrir la aplicación** en el navegador
2. **Hacer clic en "Nuevo Ticket"** si no estás en el formulario
3. **Llenar el formulario** con:
   - Nombre de la empresa cliente
   - Nombre del chofer
   - Teléfono de contacto  
   - Dirección del servicio
4. **Agregar productos/servicios**:
   - Descripción del servicio (ej: "Reparación de llanta")
   - Cantidad de servicios
   - Precio unitario
   - Usar "+" para agregar más servicios
5. **Verificar el total** calculado automáticamente
6. **Presionar "Generar Ticket"**
7. **Imprimir** usando el botón "Imprimir Ticket"
8. **🆕 Compartir** usando el botón "Compartir" - elige WhatsApp, Email, Facebook o copiar texto

### Para Ver el Historial:
1. **Hacer clic en "Historial"** en la barra superior
2. **Ver todos los tickets** generados anteriormente
3. **Reimprimir** cualquier ticket con el botón "Reimprimir"
4. **Eliminar** tickets individuales si es necesario
5. **Exportar** todo el historial en formato CSV
6. **Limpiar** todo el historial si deseas empezar de nuevo

### Ejemplos de Servicios:
- Reparación de llanta
- Cambio de llanta
- Inflado de llantas
- Servicio de grúa
- Cambio de refacción
- Balanceado de ruedas
- Alineación

## 🚀 Estado del Deployment
- **Status**: ✅ **ACTIVO** 
- **Plataforma**: Sandbox de desarrollo
- **Última actualización**: 22 de agosto, 2025
- **Funcionalidad**: 100% operativo
- **Nuevas características**: 
  - ✅ Historial local implementado
  - ✅ Impresión hoja completa con letras grandes
  - ✅ Función compartir multicanal agregada

## 📊 Ventajas del Sistema de Historial

### Para el Negocio:
- **Control de ventas**: Ve todos los servicios realizados
- **Reimpresión fácil**: No pierdas tickets importantes
- **Exportar datos**: Lleva tus registros a Excel
- **Análisis de clientes**: Identifica clientes frecuentes

### Para el Usuario:
- **Sin conexión a internet requerida**: El historial funciona offline
- **Datos seguros**: Se guardan en tu navegador
- **Acceso rápido**: Ve el historial al instante
- **Exportación simple**: Descarga CSV con un clic

## 📝 Próximos Pasos Recomendados
1. **Deploy a producción**: Migrar a Cloudflare Pages para uso permanente
2. **Backup en la nube**: Sincronizar historial con base de datos remota
3. **Reportes avanzados**: Gráficos de ventas por periodo
4. **Clientes frecuentes**: Autocompletar datos de clientes recurrentes
5. **Múltiples usuarios**: Sistema de autenticación para múltiples operadores
6. **Categorías de servicios**: Clasificar servicios por tipo
7. **Notificaciones**: Recordatorios de servicios pendientes

## 🔧 Comandos de Desarrollo
```bash
# Instalar dependencias
npm install

# Desarrollo local
npm run dev

# Construir para producción
npm run build

# Desplegar
npm run deploy:prod

# Ver logs del servidor
pm2 logs --nostream
```

## 📱 Compatibilidad
- ✅ **Navegadores**: Chrome, Firefox, Safari, Edge
- ✅ **Dispositivos**: PC, Mac, tablets, smartphones
- ✅ **Impresoras**: Térmicas (80mm), láser, inkjet
- ✅ **Sistemas**: Windows, macOS, Linux, iOS, Android

---
**Desarrollado para Llantera Móvil Cofradía - Servicio profesional las 24 horas en Mazamitla y alrededores**

🔧 **Sistema actualizado con historial completo y navegación profesional**