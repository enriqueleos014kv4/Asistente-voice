import { Hono } from 'hono'
import { cors } from 'hono/cors'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// API endpoint to handle form submission
app.post('/api/generar-ticket', async (c) => {
  const data = await c.req.json()
  
  // Generate a simple ticket ID
  const ticketId = Date.now().toString()
  
  return c.json({
    success: true,
    ticketId: ticketId,
    data: data
  })
})

// Main page
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sistema de Tickets - Llantera Móvil Cofradía</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
            @media print {
                .no-print { display: none; }
                .ticket-container {
                    width: 100% !important;
                    max-width: 100% !important;
                    height: 100vh !important;
                    margin: 0 !important;
                    padding: 20px !important;
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    background: white !important;
                }
                .ticket-content-print {
                    width: 100% !important;
                    max-width: 100% !important;
                    padding: 40px !important;
                    font-size: 21px !important;
                    line-height: 1.8 !important;
                    border: 4px solid #000 !important;
                    min-height: 90vh !important;
                }
                body { 
                    margin: 0 !important; 
                    padding: 0 !important;
                    font-size: 18px !important;
                }
                h2 { font-size: 37px !important; margin-bottom: 25px !important; }
                .logo-ticket {
                    width: 70% !important;
                    max-width: 350px !important;
                    height: auto !important;
                    margin-bottom: 35px !important;
                }
                .ticket-info {
                    font-size: 23px !important;
                    margin-bottom: 18px !important;
                }
                .ticket-productos {
                    font-size: 21px !important;
                    margin: 25px 0 !important;
                }
                .ticket-total {
                    font-size: 28px !important;
                    font-weight: bold !important;
                    margin-top: 35px !important;
                }
            }
            .logo-bw {
                filter: grayscale(100%) invert(1) contrast(1.2) brightness(1.1);
            }
            .logo-main-form {
                filter: grayscale(100%) invert(1) contrast(1.2) brightness(1.1);
                width: 100% !important;
                max-width: 400px !important;
                height: auto !important;
                max-height: 200px !important;
            }
            .logo-ticket {
                filter: grayscale(100%) invert(1) contrast(1.5) brightness(0.9);
                width: 100% !important;
                max-width: 100% !important;
                height: auto !important;
                max-height: none !important;
                min-height: 80px;
            }
            @media print {
                .logo-ticket {
                    width: 100% !important;
                    max-width: 100% !important;
                    height: auto !important;
                    max-height: none !important;
                    min-height: 60px;
                }
            }
        </style>
    </head>
    <body class="bg-gray-50 min-h-screen">
        <!-- Navigation -->
        <nav class="bg-gray-800 text-white p-4">
            <div class="max-w-6xl mx-auto flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <img src="/static/logo-header.jpg" alt="Llantera Móvil Cofradía" class="h-12 logo-bw">
                    <h1 class="text-xl font-bold">Sistema de Tickets</h1>
                </div>
                <div class="flex space-x-4">
                    <button id="btn-nuevo" class="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700">Nuevo Ticket</button>
                    <button id="btn-historial" class="px-4 py-2 bg-green-600 rounded hover:bg-green-700">Historial</button>
                </div>
            </div>
        </nav>

        <!-- Formulario de captura -->
        <div id="form-container" class="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-6 mt-6">
            <div class="text-center mb-6">
                <img src="/static/logo-main.jpg" alt="Llantera Móvil Cofradía" class="mx-auto mb-4 object-contain logo-main-form">
                <h1 class="text-2xl font-bold text-gray-800">LLANTERA MÓVIL COFRADÍA</h1>
                <p class="text-gray-600">Sistema de Generación de Tickets</p>
            </div>

            <form id="ticketForm" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Nombre de la Empresa</label>
                        <input type="text" id="empresa" name="empresa" class="w-full p-2 border border-gray-300 rounded-md" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Nombre del Chofer</label>
                        <input type="text" id="chofer" name="chofer" class="w-full p-2 border border-gray-300 rounded-md" required>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Teléfono</label>
                        <input type="tel" id="telefono" name="telefono" class="w-full p-2 border border-gray-300 rounded-md" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Dirección</label>
                        <input type="text" id="direccion" name="direccion" class="w-full p-2 border border-gray-300 rounded-md" required>
                    </div>
                </div>

                <div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">Productos/Servicios</h3>
                    <div id="productos-container">
                        <div class="producto-item bg-gray-50 p-3 rounded-md mb-2">
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-2">
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
                                    <input type="text" name="descripcion[]" class="w-full p-2 border border-gray-300 rounded-md" placeholder="Ej: Reparación de llanta" required>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Cantidad</label>
                                    <input type="number" name="cantidad[]" class="w-full p-2 border border-gray-300 rounded-md cantidad-input" min="1" value="1" required>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Precio Unitario</label>
                                    <input type="number" name="precio[]" class="w-full p-2 border border-gray-300 rounded-md precio-input" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="button" id="add-producto" class="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">+ Agregar Producto</button>
                </div>

                <div class="flex justify-between items-center pt-4 border-t">
                    <div class="text-xl font-bold text-gray-800">
                        Total: $<span id="total-amount">0.00</span>
                    </div>
                    <button type="submit" class="px-6 py-3 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700">Generar Ticket</button>
                </div>
            </form>
        </div>

        <!-- Historial -->
        <div id="historial-container" class="hidden max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6 mt-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-bold text-gray-800">Historial de Tickets</h2>
                <div class="space-x-2">
                    <button id="export-historial" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Exportar</button>
                    <button id="clear-historial" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">Limpiar Historial</button>
                </div>
            </div>
            <div id="historial-content" class="space-y-4">
                <!-- El historial se cargará aquí -->
            </div>
        </div>

        <!-- Ticket para impresión -->
        <div id="ticket-container" class="hidden max-w-sm mx-auto bg-white ticket-container mt-6" style="width: 80mm;">
            <div class="p-3 text-center border-2 border-dashed border-gray-400 ticket-content-print">
                <div class="mb-3 w-full">
                    <img src="/static/logo-main.jpg" alt="Logo" class="mx-auto mb-2 logo-ticket">
                </div>
                <h2 class="text-base font-bold mb-1">LLANTERA MÓVIL COFRADÍA</h2>
                <p class="text-xs ticket-info">SERVICIO A DOMICILIO 24HR</p>
                <p class="text-xs ticket-info">MAZAMITLA, JAL</p>
                <p class="text-xs font-semibold ticket-info">Tel: 333-485-4080</p>
                <hr class="my-3 border-dashed">
                
                <div id="ticket-content" class="text-left text-xs space-y-1 ticket-productos">
                    <!-- El contenido se llenará dinámicamente -->
                </div>
                
                <hr class="my-3 border-dashed">
                <p class="text-xs text-center ticket-info">¡Gracias por su confianza!</p>
                <p class="text-xs text-center font-semibold ticket-info" id="ticket-fecha"></p>
                
                <!-- Espacio adicional para llenar la página -->
                <div class="mt-8 text-center ticket-info">
                    <p class="text-sm">────────────────────────────────</p>
                    <p class="text-sm mt-4">LLANTERA MÓVIL COFRADÍA</p>
                    <p class="text-sm">Su mejor opción en servicio de llantas</p>
                    <p class="text-sm">Disponible las 24 horas del día</p>
                    <p class="text-sm mt-4">────────────────────────────────</p>
                </div>
            </div>
            
            <div class="text-center mt-4 no-print">
                <button onclick="window.print()" class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 mr-2 mb-2">Imprimir Ticket</button>
                <button onclick="compartirTicket()" class="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 mr-2 mb-2">Compartir</button>
                <button onclick="nuevoTicket()" class="px-6 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 mb-2">Nuevo Ticket</button>
            </div>
            
            <!-- Modal de compartir -->
            <div id="modal-compartir" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 no-print">
                <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                    <h3 class="text-xl font-bold mb-4 text-center">Compartir Ticket</h3>
                    <div class="grid grid-cols-2 gap-3">
                        <button onclick="compartirWhatsApp()" class="flex items-center justify-center px-4 py-3 bg-green-500 text-white rounded-md hover:bg-green-600">
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.516"/>
                            </svg>
                            WhatsApp
                        </button>
                        <button onclick="compartirEmail()" class="flex items-center justify-center px-4 py-3 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                            </svg>
                            Email
                        </button>
                        <button onclick="compartirFacebook()" class="flex items-center justify-center px-4 py-3 bg-blue-700 text-white rounded-md hover:bg-blue-800">
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                            </svg>
                            Facebook
                        </button>
                        <button onclick="compartirTexto()" class="flex items-center justify-center px-4 py-3 bg-gray-500 text-white rounded-md hover:bg-gray-600">
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
                            </svg>
                            Copiar Texto
                        </button>
                    </div>
                    <button onclick="cerrarModal()" class="mt-4 w-full px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancelar</button>
                </div>
            </div>
        </div>

        <script>
            // Variables globales
            let productos = [];
            let historialTickets = JSON.parse(localStorage.getItem('historialTickets') || '[]');
            
            // Inicialización
            document.addEventListener('DOMContentLoaded', function() {
                cargarHistorial();
                calcularTotal();
            });

            // Navegación
            document.getElementById('btn-nuevo').addEventListener('click', function() {
                mostrarFormulario();
            });

            document.getElementById('btn-historial').addEventListener('click', function() {
                mostrarHistorial();
            });

            // Funciones de navegación
            function mostrarFormulario() {
                document.getElementById('form-container').classList.remove('hidden');
                document.getElementById('historial-container').classList.add('hidden');
                document.getElementById('ticket-container').classList.add('hidden');
            }

            function mostrarHistorial() {
                document.getElementById('form-container').classList.add('hidden');
                document.getElementById('historial-container').classList.remove('hidden');
                document.getElementById('ticket-container').classList.add('hidden');
                cargarHistorial();
            }

            // Calcular total
            function calcularTotal() {
                const cantidadInputs = document.querySelectorAll('.cantidad-input');
                const precioInputs = document.querySelectorAll('.precio-input');
                let total = 0;
                
                for (let i = 0; i < cantidadInputs.length; i++) {
                    const cantidad = parseFloat(cantidadInputs[i].value) || 0;
                    const precio = parseFloat(precioInputs[i].value) || 0;
                    total += cantidad * precio;
                }
                
                document.getElementById('total-amount').textContent = total.toFixed(2);
            }
            
            // Agregar producto
            document.getElementById('add-producto').addEventListener('click', function() {
                const container = document.getElementById('productos-container');
                const newProducto = document.createElement('div');
                newProducto.className = 'producto-item bg-gray-50 p-3 rounded-md mb-2';
                newProducto.innerHTML = \`
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-2">
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
                            <input type="text" name="descripcion[]" class="w-full p-2 border border-gray-300 rounded-md" placeholder="Ej: Cambio de llanta" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Cantidad</label>
                            <input type="number" name="cantidad[]" class="w-full p-2 border border-gray-300 rounded-md cantidad-input" min="1" value="1" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Precio Unitario</label>
                            <input type="number" name="precio[]" class="w-full p-2 border border-gray-300 rounded-md precio-input" min="0" step="0.01" placeholder="0.00" required>
                        </div>
                    </div>
                    <button type="button" class="remove-producto mt-2 text-red-600 hover:text-red-800" onclick="this.parentElement.remove(); calcularTotal();">Eliminar</button>
                \`;
                container.appendChild(newProducto);
            });
            
            // Escuchar cambios en cantidad y precio
            document.addEventListener('input', function(e) {
                if (e.target.classList.contains('cantidad-input') || e.target.classList.contains('precio-input')) {
                    calcularTotal();
                }
            });
            
            // Manejar envío del formulario
            document.getElementById('ticketForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const data = {
                    empresa: formData.get('empresa'),
                    chofer: formData.get('chofer'),
                    telefono: formData.get('telefono'),
                    direccion: formData.get('direccion'),
                    productos: [],
                    total: parseFloat(document.getElementById('total-amount').textContent),
                    fecha: new Date().toLocaleString('es-MX')
                };
                
                const descripciones = formData.getAll('descripcion[]');
                const cantidades = formData.getAll('cantidad[]');
                const precios = formData.getAll('precio[]');
                
                for (let i = 0; i < descripciones.length; i++) {
                    if (descripciones[i].trim()) {
                        data.productos.push({
                            descripcion: descripciones[i],
                            cantidad: parseInt(cantidades[i]),
                            precio: parseFloat(precios[i]),
                            subtotal: parseInt(cantidades[i]) * parseFloat(precios[i])
                        });
                    }
                }
                
                try {
                    const response = await fetch('/api/generar-ticket', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        // Guardar en historial
                        const ticketCompleto = {
                            ...data,
                            ticketId: result.ticketId,
                            fechaCreacion: new Date().toISOString()
                        };
                        
                        historialTickets.unshift(ticketCompleto); // Agregar al inicio
                        localStorage.setItem('historialTickets', JSON.stringify(historialTickets));
                        
                        mostrarTicket(data, result.ticketId);
                    }
                } catch (error) {
                    alert('Error al generar el ticket: ' + error.message);
                }
            });
            
            function mostrarTicket(data, ticketId) {
                // Guardar ticket actual para compartir
                ticketActual = {
                    ...data,
                    ticketId: ticketId,
                    fechaCreacion: new Date().toISOString()
                };
                
                const ticketContent = document.getElementById('ticket-content');
                const fecha = new Date().toLocaleString('es-MX');
                
                let html = \`
                    <p><strong>Ticket:</strong> #\${ticketId}</p>
                    <p><strong>Empresa:</strong> \${data.empresa}</p>
                    <p><strong>Chofer:</strong> \${data.chofer}</p>
                    <p><strong>Teléfono:</strong> \${data.telefono}</p>
                    <p><strong>Dirección:</strong> \${data.direccion}</p>
                    <hr class="my-2 border-dashed">
                    <p class="font-semibold">PRODUCTOS/SERVICIOS:</p>
                \`;
                
                data.productos.forEach(producto => {
                    html += \`
                        <div class="flex justify-between">
                            <span>\${producto.cantidad}x \${producto.descripcion}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>@$\${producto.precio.toFixed(2)}</span>
                            <span>$\${producto.subtotal.toFixed(2)}</span>
                        </div>
                    \`;
                });
                
                html += \`
                    <hr class="my-2 border-dashed">
                    <div class="flex justify-between font-bold">
                        <span>TOTAL:</span>
                        <span>$\${data.total.toFixed(2)}</span>
                    </div>
                \`;
                
                ticketContent.innerHTML = html;
                document.getElementById('ticket-fecha').textContent = fecha;
                
                // Mostrar ticket
                document.getElementById('form-container').classList.add('hidden');
                document.getElementById('historial-container').classList.add('hidden');
                document.getElementById('ticket-container').classList.remove('hidden');
            }
            
            function nuevoTicket() {
                mostrarFormulario();
                document.getElementById('ticketForm').reset();
                calcularTotal();
            }

            // Funciones del historial
            function cargarHistorial() {
                const container = document.getElementById('historial-content');
                
                if (historialTickets.length === 0) {
                    container.innerHTML = '<p class="text-gray-500 text-center py-8">No hay tickets en el historial</p>';
                    return;
                }
                
                let html = '';
                historialTickets.forEach((ticket, index) => {
                    const fecha = new Date(ticket.fechaCreacion).toLocaleString('es-MX');
                    html += \`
                        <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                            <div class="flex justify-between items-start mb-2">
                                <div>
                                    <h3 class="font-semibold text-lg">Ticket #\${ticket.ticketId}</h3>
                                    <p class="text-sm text-gray-600">\${fecha}</p>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold text-lg text-green-600">$\${ticket.total.toFixed(2)}</p>
                                    <div class="space-x-2">
                                        <button onclick="reimprimirTicket(\${index})" class="text-blue-600 hover:text-blue-800 text-sm">Reimprimir</button>
                                        <button onclick="eliminarTicket(\${index})" class="text-red-600 hover:text-red-800 text-sm">Eliminar</button>
                                    </div>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <p><strong>Empresa:</strong> \${ticket.empresa}</p>
                                    <p><strong>Chofer:</strong> \${ticket.chofer}</p>
                                </div>
                                <div>
                                    <p><strong>Teléfono:</strong> \${ticket.telefono}</p>
                                    <p><strong>Servicios:</strong> \${ticket.productos.length} item(s)</p>
                                </div>
                            </div>
                        </div>
                    \`;
                });
                
                container.innerHTML = html;
            }

            function reimprimirTicket(index) {
                const ticket = historialTickets[index];
                ticketActual = ticket; // Guardar para compartir
                mostrarTicket(ticket, ticket.ticketId);
            }

            function eliminarTicket(index) {
                if (confirm('¿Estás seguro de eliminar este ticket del historial?')) {
                    historialTickets.splice(index, 1);
                    localStorage.setItem('historialTickets', JSON.stringify(historialTickets));
                    cargarHistorial();
                }
            }

            // Exportar historial
            document.getElementById('export-historial').addEventListener('click', function() {
                if (historialTickets.length === 0) {
                    alert('No hay tickets para exportar');
                    return;
                }

                const csvContent = generarCSV();
                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement('a');
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', \`historial_tickets_\${new Date().toISOString().split('T')[0]}.csv\`);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });

            function generarCSV() {
                let csv = 'Fecha,Ticket ID,Empresa,Chofer,Telefono,Direccion,Servicios,Total\\n';
                
                historialTickets.forEach(ticket => {
                    const fecha = new Date(ticket.fechaCreacion).toLocaleString('es-MX');
                    const servicios = ticket.productos.map(p => \`\${p.cantidad}x \${p.descripcion}\`).join('; ');
                    
                    csv += \`"\${fecha}","\${ticket.ticketId}","\${ticket.empresa}","\${ticket.chofer}","\${ticket.telefono}","\${ticket.direccion}","\${servicios}","\${ticket.total.toFixed(2)}"\\n\`;
                });
                
                return csv;
            }

            // Limpiar historial
            document.getElementById('clear-historial').addEventListener('click', function() {
                if (confirm('¿Estás seguro de limpiar todo el historial? Esta acción no se puede deshacer.')) {
                    historialTickets = [];
                    localStorage.removeItem('historialTickets');
                    cargarHistorial();
                    alert('Historial limpiado correctamente');
                }
            });

            // Variables globales para compartir
            let ticketActual = null;

            // Funciones de compartir
            function compartirTicket() {
                if (!ticketActual) {
                    alert('No hay ticket para compartir');
                    return;
                }
                document.getElementById('modal-compartir').classList.remove('hidden');
            }

            function cerrarModal() {
                document.getElementById('modal-compartir').classList.add('hidden');
            }

            function generarTextoTicket() {
                if (!ticketActual) return '';
                
                let texto = \`📧 TICKET DE SERVICIO #\${ticketActual.ticketId}\\n\`;
                texto += \`🏢 LLANTERA MÓVIL COFRADÍA\\n\`;
                texto += \`📞 Tel: 333-485-4080\\n\`;
                texto += \`📍 Mazamitla, Jalisco\\n\`;
                texto += \`⏰ Servicio 24 horas\\n\\n\`;
                
                texto += \`👤 CLIENTE:\\n\`;
                texto += \`🏢 Empresa: \${ticketActual.empresa}\\n\`;
                texto += \`🚛 Chofer: \${ticketActual.chofer}\\n\`;
                texto += \`📞 Teléfono: \${ticketActual.telefono}\\n\`;
                texto += \`📍 Dirección: \${ticketActual.direccion}\\n\\n\`;
                
                texto += \`🔧 SERVICIOS REALIZADOS:\\n\`;
                ticketActual.productos.forEach(producto => {
                    texto += \`• \${producto.cantidad}x \${producto.descripcion} - $\${producto.subtotal.toFixed(2)}\\n\`;
                });
                
                texto += \`\\n💰 TOTAL: $\${ticketActual.total.toFixed(2)}\\n\`;
                texto += \`📅 Fecha: \${new Date(ticketActual.fechaCreacion).toLocaleString('es-MX')}\\n\\n\`;
                texto += \`✅ ¡Gracias por confiar en nosotros!\\n\`;
                texto += \`🚚 Llantera Móvil Cofradía - Tu mejor opción\`;
                
                return texto;
            }

            function compartirWhatsApp() {
                const texto = generarTextoTicket();
                const url = \`https://wa.me/?text=\${encodeURIComponent(texto)}\`;
                window.open(url, '_blank');
                cerrarModal();
            }

            function compartirEmail() {
                const texto = generarTextoTicket();
                const asunto = \`Ticket #\${ticketActual.ticketId} - Llantera Móvil Cofradía\`;
                const url = \`mailto:?subject=\${encodeURIComponent(asunto)}&body=\${encodeURIComponent(texto)}\`;
                window.open(url, '_blank');
                cerrarModal();
            }

            function compartirFacebook() {
                const texto = \`Ticket de servicio #\${ticketActual.ticketId} - Llantera Móvil Cofradía. Total: $\${ticketActual.total.toFixed(2)}. ¡Servicio profesional 24 horas en Mazamitla!\`;
                const url = \`https://www.facebook.com/sharer/sharer.php?u=\${encodeURIComponent(window.location.href)}&quote=\${encodeURIComponent(texto)}\`;
                window.open(url, '_blank');
                cerrarModal();
            }

            function compartirTexto() {
                const texto = generarTextoTicket();
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(texto).then(() => {
                        alert('¡Texto del ticket copiado al portapapeles!');
                    }).catch(() => {
                        mostrarTextoParaCopiar(texto);
                    });
                } else {
                    mostrarTextoParaCopiar(texto);
                }
                cerrarModal();
            }

            function mostrarTextoParaCopiar(texto) {
                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                modal.innerHTML = \`
                    <div class="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-96 overflow-y-auto">
                        <h3 class="text-xl font-bold mb-4">Copiar Texto del Ticket</h3>
                        <textarea class="w-full h-64 p-3 border border-gray-300 rounded-md text-sm" readonly>\${texto}</textarea>
                        <div class="mt-4 text-center">
                            <button onclick="this.parentElement.parentElement.parentElement.remove()" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Cerrar</button>
                        </div>
                    </div>
                \`;
                document.body.appendChild(modal);
            }

            // Cerrar modal al hacer clic fuera
            document.addEventListener('click', function(e) {
                const modal = document.getElementById('modal-compartir');
                if (e.target === modal) {
                    cerrarModal();
                }
            });
        </script>
    </body>
    </html>
  `)
})

export default app